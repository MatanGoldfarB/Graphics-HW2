#include "Vector.h"
#include "Ray.h"



    Ray :: Ray(const Vector& o, const Vector& d) : origin(o), direction(d) {}
